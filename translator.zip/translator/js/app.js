const button = document.querySelector("button");
const wordInput = document.querySelector("input");
const searcedsynonyms = document.querySelector(".search-word");
const soundIcon = document.querySelector(".word-sound svg");
const searchType = document.querySelector(".search-type");
const searchPro = document.querySelector(".search-pronunciation");
const description = document.querySelector(".description-section p");
const audio = document.querySelector("audio");

const translateHandler = () => {
  const inputValue = wordInput.value.trim().toLowerCase();
  const baisUrl = `https://api.dictionaryapi.dev/api/v2/entries/en/${inputValue}`;
  fetch(baisUrl)
    .then((response) => {
      if (response.status === 200) {
        return response.json();
      }
    })
    .then((data) => {
      audio.setAttribute("src", data[0].phonetics[1].audio);
      searcedsynonyms.innerHTML = data[0].meanings[0].synonyms[1];
      searchType.innerHTML = data[0].meanings[0].partOfSpeech;
      searchPro.innerHTML = data[0].phonetic;
      description.innerHTML = data[0].meanings[0].definitions[0].definition;
      soundIcon.addEventListener("click", () => {
        audio.play();
      });
    })
    .catch((err) => console.log(err));
};

button.addEventListener("click", translateHandler);
window.addEventListener("keyup", (event) => {
  if (event.key === "Enter") {
    translateHandler();
  }
});
