# Public API Translator

## Description
A simple translation app that fetches text from a public translation API and displays the translated result. Built for testing and learning API integration using `fetch()`.

## Features
- Fetches translation from a public API  
- Clean and minimal UI  
- Easy to customize and extend  

## Installation
```bash